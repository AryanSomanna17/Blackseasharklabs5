-- REVIEW BEFORE RUNNING. Run manually in the Supabase SQL editor; nothing applies this automatically.
-- Purpose: add an explicit public-release flag so the website only shows approved papers.
--
-- STEP 0 (read-only): look at your current policies first.
--   select policyname, roles, cmd, qual, with_check
--   from pg_policies where schemaname = 'public' and tablename = 'publications';
-- Policies are permissive (OR-ed). Any existing SELECT policy that allows anon/public to read
-- all rows (e.g. USING (true)) keeps every row readable through the API, whatever is_public says.
-- If you see one, drop or narrow it yourself after checking what depends on it.

-- STEP 1: add columns. Existing rows get is_public = false (hidden until you approve them).
alter table public.publications
  add column if not exists is_public boolean not null default false,
  add column if not exists status    text check (status in ('published','preprint','ongoing')),
  add column if not exists pdf_url   text,
  add column if not exists doi_url   text;

-- STEP 2: allow anonymous visitors to read approved rows only.
alter table public.publications enable row level security;

drop policy if exists "public can read approved publications" on public.publications;
create policy "public can read approved publications"
  on public.publications for select
  to anon, authenticated
  using (is_public = true);

-- This migration deliberately does NOT create or replace any write/admin policy.
-- Your existing insert/update/delete policies keep working unchanged.
-- The admin list screen reads ALL rows (including unapproved). If, after STEP 2, the admin
-- screen no longer lists unapproved papers, add an admin-only SELECT policy that matches how
-- you already restrict admin writes (for example, limited to your admin user's id or email):
--
--   create policy "admin can read all publications"
--     on public.publications for select to authenticated
--     using ((auth.jwt() ->> 'email') = 'YOUR-ADMIN-EMAIL');
--
-- Do not use USING (true) for authenticated unless every signed-in user is trusted.

-- STEP 3: approve papers one at a time in Admin -> Publications (tick "Approved for public release"),
-- only after the owners have confirmed release.
-- Never point pdf_url at a private storage bucket; use a public link or a signed/public file you
-- have deliberately released.
